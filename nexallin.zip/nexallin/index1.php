<?php 
// Cache control headers - enhanced to prevent all caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT"); // Always modified

if(isset($_GET['route'])){
    $route = $_GET['route'];
}else{
    $route = 'index';
}

$routes = array(
    'index' => 'home.php',
    'about' => 'about.php',

    'vc' => 'vc.php',
        'marlop'=> 'marlop.php',
        'pirrm'=> 'pirrm.php',
        'ict'=> 'ict.php',
            'software'=> 'software.php',
            'hardware'=> 'hardware.php',
            'support' => 'help_desk.php',
        'monitoring'=> 'monitoring.php',
        'risk'=> 'risk.php',
        'audit'=> 'audit.php',


    'pvc' => 'pvc.php',
    'bursary' => 'bursary.php',
    'registrar' => 'registrar.php',
        'registry-academic' => 'academic.php',
    'library' => 'library.php',


    'fpast'=> 'fpast.php',
    'animal-production'=> 'animal_prod.php',
    'agricultural-extension' => 'agric_exten.php',
    'horticulture'=> 'horticulture.php',
    'crop-science'=> 'crop_science.php',

    'fees'=> 'fees.php',
    'wild-life'=> 'wfm.php',
    'soil-science'=> 'soil_science.php',
    'natural-resources'=> 'nrm.php',
    'environment'=> 'environment_science.php',

    'fast' => 'fast.php',
    'gis' => 'fast_ges.php',
    'fdt' => 'fast_fdt.php',

    'f-a-e' => 'fae.php',
    'agri-business' => 'agri_man.php',
    'supply-chain' => 'sup_chain.php',
    'development-studies' => 'dev_studies.php',
    'marketing' => 'marketing.php',

    'fbt' => 'fbt.php',

    'fdbs' => 'dbs.php',


    'innovation'=> 'innovation.php',
    'caet'=> 'caet.php',
    'ccfsi'=> 'ccfsi.php',
    'aivi'=> 'aivi.php',
    'tli'=> 'tli.php',
    'qapd'=> 'qapd.php',
    'crps'=> 'crps.php',

    'gallery' => 'gallery.php',

    'careers' => 'vacancies.php',

    'alumni'=> 'alumni.php',
    'client-service'=> 'client_service.php',



    //it was on congrats section on home.php
    'img-1' => 'image-viewer.php',
    'img-2' => 'image-viewer.php',
    'img-3' => 'image-viewer.php',
    'img-4' => 'image-viewer.php',
    'img-5' => 'image-viewer.php',
    'img-6' => 'image-viewer.php',

    //on  admission steps
    'admission-steps' => 'document-viewer.php',

    //on  highlights section
    'highlights' => 'document-viewer.php',
      
    // on notices section
    'document-1' => 'document-viewer.php',
    'document-2' => 'document-viewer.php',
    'document-3' => 'document-viewer.php',
    'document-4' => 'document-viewer.php',
    'document-5' => 'document-viewer.php',
    'document-6' => 'document-viewer.php',
    'document-7' => 'document-viewer.php',
    'document-8' => 'document-viewer.php',
    'document-9' => 'document-viewer.php',
    'document-10' => 'document-viewer.php',
    'document-11' => 'document-viewer.php',
    'document-12' => 'document-viewer.php',
    'document-13' => 'document-viewer.php',
    'document-14' => 'document-viewer.php',
    'document-15' => 'document-viewer.php',
    'document-16' => 'document-viewer.php',
    'document-17' => 'document-viewer.php',
    'document-18' => 'document-viewer.php',
    

    //on  vacancy section
    'vacancy-1' => 'document-viewer.php',
    'vacancy-2' => 'document-viewer.php',
    'vacancy-3' => 'document-viewer.php',
    'vacancy-4' => 'document-viewer.php',
    'vacancy-5' => 'document-viewer.php',
    'vacancy-6' => 'document-viewer.php',
    'vacancy-7' => 'document-viewer.php',

    //client service charter
    'english'=> 'document-viewer.php',
    'ndebele'=> 'document-viewer.php',
    'tonga'=> 'document-viewer.php',
    'shona'=> 'document-viewer.php',

    //documents on congratulations section
    'congrats-1' => 'document-viewer.php',
    'congrats-2' => 'document-viewer.php',
    'congrats-3' => 'document-viewer.php',

    //documents on scholarships section
    'scholar-1' => 'document-viewer.php',
    'scholar-2' => 'document-viewer.php',


    

);

if(array_key_exists($route, $routes)){
    include $routes[$route];
}else{
    include '404.php';
}



?>
