<?php
include('includes/head.php');
?>

<body class="testimonials-page">

  <?php
  include('includes/header.php');
  ?>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title dark-background" data-aos="fade" style="background-image: url(assets/img/page-title-bg.webp);">
      <div class="container position-relative">
        <h1>Our Team</h1>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">Our Team</li>
          </ol>
        </nav>
      </div>
    </div><!-- End Page Title -->

    <!-- Testimonials Section -->
    <section class="testimonials-12 testimonials section" id="testimonials">
      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Meet Nexal Team</h2>
      </div><!-- End Section Title -->

      <div class="testimonial-wrap">
        <div class="container">
          <div class="row">
            <div class="col-md-6 mb-4 mb-md-4">
              <div class="testimonial">
                <img src="assets/img/team/Mavis Moyo.jpg" alt="Testimonial author">
                <blockquote>
                  <p>
                    “Accountable Manager, an Agricultural Economists by profession: Oversees overall management
                    and compliance of all drone operations and ensures resource availability and adherence to
                    regulatory and company standards”
                  </p>
                </blockquote>
                <p class="client-name">Mavis Moyo</p>
              </div>
            </div>
            <div class="col-md-6 mb-4 mb-md-4">
              <div class="testimonial">
                <img src="assets/img/team/Tafadzwa Chademana.jpg" alt="Testimonial author">
                <blockquote>
                  <p>
                    “Quality Manager, an Agronomist by profession: Responsible for maintaining high quality
                    operational standards across all technical activities.”
                  </p>
                </blockquote>
                <p class="client-name">Tafadzwa Chademana</p>
              </div>
            </div>
            <div class="col-md-6 mb-4 mb-md-4">
              <div class="testimonial">
                <img src="assets/img/team/Blessing Kokera.jpg" alt="Testimonial author">
                <blockquote>
                  <p>
                    “Chief Pilot, qualified drone pilot who is an Engineer by profession: Leads
                    flight operations, pre and post flight planning and oversees the safe execution of all aerial missions.”
                  </p>
                </blockquote>
                <p class="client-name">Blessing Kokera</p>
              </div>
            </div>
            <div class="col-md-6 mb-4 mb-md-4">
              <div class="testimonial">
                <img src="assets/img/team/Chengeto Koza.jpg" alt="Testimonial author">
                <blockquote>
                  <p>
                    “Safety Manager, an Agronomist by profession: Responsible for risk analysis and management,
                    safety regulation compliance and continuous improvement guided by our safety culture.”
                  </p>
                </blockquote>
                <p class="client-name">Chengeto Koza</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section><!-- /Testimonials Section -->

<?php
  include('includes/subscriber.php');
  ?>

  </main>

  <?php
  include('includes/footer.php');
  ?>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>
  <!-- JavaScript to trigger the modal -->
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const readMoreLink = document.getElementById('readMoreLink');
      const backgroundModal = new bootstrap.Modal(document.getElementById('backgroundModal'));

      readMoreLink.addEventListener('click', function(e) {
        e.preventDefault();
        backgroundModal.show();
      });
    });
  </script>

</body>

</html>