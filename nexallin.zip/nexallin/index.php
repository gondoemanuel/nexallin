<?php
include('includes/head.php');
?>

<body class="index-page">

  <?php
  include('includes/header.php');
  ?>

  <main class="main">

    <!-- Hero Section -->
    <section id="hero" class="hero section dark-background">

      <div id="hero-carousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="5000">

        <div class="carousel-item active">
          <img src="assets/img/Drone spraying.jpg" alt="">
          <div class="carousel-container">
            <h2>Drone spraying</h2>
            <!-- <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p> -->
          </div>
        </div><!-- End Carousel Item -->

        <div class="carousel-item">
          <img src="assets/img/Field scouting.jpg" alt="">
          <div class="carousel-container">
            <h2>Field scouting</h2>
            <!-- <p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus.</p> -->
          </div>
        </div><!-- End Carousel Item -->

        <div class="carousel-item">
          <img src="assets/img/Aerial imagery and mapping.jpg" alt="">
          <div class="carousel-container">
            <h2>Aerial imagery and mapping</h2>
            <!-- <p>Beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit.</p> -->
          </div>
        </div><!-- End Carousel Item -->

        <div class="carousel-item">
          <img src="assets/img/img.jpg" alt="">
          <div class="carousel-container">
            <h2>Farming as a Passione</h2>
            <!-- <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius.</p> -->
          </div>
        </div><!-- End Carousel Item -->

        <div class="carousel-item">
          <img src="assets/img/slider_1.jpg" alt="">
          <div class="carousel-container">
            <h2>Farm Smart, Not Hard - Nexal's AI Drones Give You Power to Cut Costs!</h2>
            <!-- <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p> -->
          </div>
        </div><!-- End Carousel Item -->

        <a class="carousel-control-prev" href="#hero-carousel" role="button" data-bs-slide="prev">
          <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
        </a>

        <a class="carousel-control-next" href="#hero-carousel" role="button" data-bs-slide="next">
          <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
        </a>

        <ol class="carousel-indicators"></ol>

      </div>

    </section><!-- /Hero Section -->

    <!-- Services Section -->
    <section id="services" class="services section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Nexal Services</h2>
        <!-- <p>Providing Fresh Produce Every Single Day</p> -->
      </div><!-- End Section Title -->

      <div class="content">
        <div class="container">
          <!-- First Row - 3 columns -->
          <div class="row g-4 mb-4">
            <div class="col-lg-4 col-md-6">
              <div class="service-item h-100">
                <span class="number">01</span>
                <div class="service-item-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="80" height="80" x="0" y="0" viewBox="0 0 512 512" style="enable-background: new 0 0 512 512" xml:space="preserve" class="">
                    <g>
                      <path d="M497 61H301c-8.284 0-15 6.716-15 15v120c0 8.284 6.716 15 15 15h196c8.284 0 15-6.716 15-15V76c0-8.284-6.716-15-15-15zm-15 120H316V91h166v90zM211 61H15C6.716 61 0 67.716 0 76v120c0 8.284 6.716 15 15 15h196c8.284 0 15-6.716 15-15V76c0-8.284-6.716-15-15-15zm-15 120H30V91h166v90zM497 241H301c-8.284 0-15 6.716-15 15v120c0 8.284 6.716 15 15 15h196c8.284 0 15-6.716 15-15V256c0-8.284-6.716-15-15-15zm-15 120H316v-90h166v90zM211 241H15c-8.284 0-15 6.716-15 15v120c0 8.284 6.716 15 15 15h196c8.284 0 15-6.716 15-15V256c0-8.284-6.716-15-15-15zm-15 120H30v-90h166v90zM437 0c-8.284 0-15 6.716-15 15v31c0 8.284 6.716 15 15 15s15-6.716 15-15V15c0-8.284-6.716-15-15-15zM377 15c-8.284 0-15 6.716-15 15s6.716 15 15 15h15c8.284 0 15-6.716 15-15s-6.716-15-15-15h-15zM467 15h-15c-8.284 0-15 6.716-15 15s6.716 15 15 15h15c8.284 0 15-6.716 15-15s-6.716-15-15-15zM75 421c-8.284 0-15 6.716-15 15v61c0 8.284 6.716 15 15 15s15-6.716 15-15v-61c0-8.284-6.716-15-15-15zM135 466h-15c-8.284 0-15 6.716-15 15s6.716 15 15 15h15c8.284 0 15-6.716 15-15s-6.716-15-15-15zM45 466H30c-8.284 0-15 6.716-15 15s6.716 15 15 15h15c8.284 0 15-6.716 15-15s-6.716-15-15-15z" fill="currentColor" opacity="1" data-original="currentColor" />
                    </g>
                  </svg>

                </div>
                <div class="service-item-content">
                  <h3 class="service-heading">Precision Crop Monitoring and Analysis</h3>
                  <p>
                    High-resolution drone imagery for early detection of crop stress, pests, and diseases—helping farmers take timely action.
                  </p>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6">
              <div class="service-item h-100">
                <span class="number">02</span>
                <div class="service-item-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="80" height="80" x="0" y="0" viewBox="0 0 512 512" style="enable-background: new 0 0 512 512" xml:space="preserve" class="">
                    <g>
                      <path d="M509.495 148.465c-3.337-7.162-11.99-10.279-19.151-6.94l-75.891 35.365-135.266-67.633 36.066-70.02c2.858-5.551.774-12.393-4.777-15.251-5.553-2.859-12.393-.774-15.251 4.777l-39.225 76.163-79.599-39.8c-6.894-3.447-15.227-.638-18.675 6.257L125.12 130.91 19.151 85.525c-7.162-3.337-15.814-.222-19.151 6.94-3.337 7.162-.222 15.814 6.94 19.151l114.465 53.344-22.368 48.04c-1.947 4.183-.868 9.153 2.645 12.198l91.791 79.547-38.508 82.72c-2.428 5.214-.168 11.419 5.046 13.847 1.419.66 2.916.973 4.395.973 3.929 0 7.693-2.195 9.452-5.999l40.614-87.238 227.583 197.231c3.509 3.041 8.479 4.12 12.662 2.174 4.183-1.947 6.894-6.104 6.894-10.587V168.249l73.944-34.451c7.162-3.338 10.277-11.99 6.94-19.152zM436.033 467.522 224.802 283.841c-3.509-3.041-8.479-4.12-12.662-2.174-4.183 1.947-6.894 6.104-6.894 10.587v39.919l-68.403-59.28 18.419-39.559 239.771 119.885v114.303zM436.033 297.5 173.847 165.562l13.194-28.329 249.892 124.955V297.5z" fill="currentColor" opacity="1" data-original="currentColor" />
                      <circle cx="91" cy="421" r="15" fill="currentColor" opacity="1" data-original="currentColor" />
                      <circle cx="151" cy="451" r="15" fill="currentColor" opacity="1" data-original="currentColor" />
                      <circle cx="31" cy="361" r="15" fill="currentColor" opacity="1" data-original="currentColor" />
                      <circle cx="61" cy="481" r="15" fill="currentColor" opacity="1" data-original="currentColor" />
                      <circle cx="121" cy="331" r="15" fill="currentColor" opacity="1" data-original="currentColor" />
                    </g>
                  </svg>

                </div>
                <div class="service-item-content">
                  <h3 class="service-heading">Aerial Crop Protection and Spraying</h3>
                  <p>
                    Efficient, uniform, and targeted spraying of pesticides, herbicides, and fertilizers using AI-calibrated drones to reduce waste and ensure precision.
                  </p>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6">
              <div class="service-item h-100">
                <span class="number">03</span>
                <div class="service-item-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="80" height="80" x="0" y="0" viewBox="0 0 512 512" style="enable-background: new 0 0 512 512" xml:space="preserve" class="">
                    <g>
                      <path d="M346.547 315.152c19.888-25.853 31.738-58.207 31.738-93.152 0-82.986-67.514-150.5-150.5-150.5S77.285 139.014 77.285 222s67.514 150.5 150.5 150.5c34.945 0 67.299-11.85 93.152-31.738l121.097 121.097c2.929 2.929 6.768 4.394 10.606 4.394s7.678-1.464 10.606-4.394c5.858-5.858 5.858-15.355 0-21.213L342.547 315.152zM107.285 222c0-66.444 54.056-120.5 120.5-120.5s120.5 54.056 120.5 120.5-54.056 120.5-120.5 120.5-120.5-54.056-120.5-120.5z" fill="currentColor" opacity="1" data-original="currentColor" />
                      <path d="M227.785 131.5c-8.284 0-15 6.716-15 15 0 41.355-33.645 75-75 75-8.284 0-15 6.716-15 15s6.716 15 15 15c57.897 0 105-47.103 105-105 0-8.284-6.716-15-15-15zM497 0H181c-8.284 0-15 6.716-15 15s6.716 15 15 15h301v331c0 8.284 6.716 15 15 15s15-6.716 15-15V15c0-8.284-6.716-15-15-15zM437 60H121c-8.284 0-15 6.716-15 15s6.716 15 15 15h301v271c0 8.284 6.716 15 15 15s15-6.716 15-15V75c0-8.284-6.716-15-15-15zM61 120H15c-8.284 0-15 6.716-15 15v362c0 8.284 6.716 15 15 15h46c8.284 0 15-6.716 15-15V135c0-8.284-6.716-15-15-15zm-15 362H30V150h16v332z" fill="currentColor" opacity="1" data-original="currentColor" />
                    </g>
                  </svg>

                </div>
                <div class="service-item-content">
                  <h3 class="service-heading">Soil Mapping and Analysis</h3>
                  <p>
                    Comprehensive soil data collection and mapping to guide fertilizer use, irrigation planning, and land management decisions.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <!-- Second Row - 3 columns -->
          <div class="row g-4">
            <div class="col-lg-4 col-md-6">
              <div class="service-item h-100">
                <span class="number">04</span>
                <div class="service-item-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="80" height="80" x="0" y="0" viewBox="0 0 512 512" style="enable-background: new 0 0 512 512" xml:space="preserve" class="">
                    <g>
                      <path d="M497 226h-51.787c-12.985-58.303-55.694-106.012-111.213-124.213V15c0-8.284-6.716-15-15-15h-127c-8.284 0-15 6.716-15 15v86.787C120.481 119.988 77.772 167.697 64.787 226H15c-8.284 0-15 6.716-15 15v45c0 8.284 6.716 15 15 15h49.025c11.933 60.395 56.486 109.948 115.975 127.025V497c0 8.284 6.716 15 15 15h127c8.284 0 15-6.716 15-15v-68.975c59.489-17.077 104.042-66.63 115.975-127.025H497c8.284 0 15-6.716 15-15v-45c0-8.284-6.716-15-15-15zM207 30h98v60h-98V30zm98 452h-98v-53h98v53zm-98-83v-15h98v15h-98zm128-83c0 52.383-42.617 95-95 95s-95-42.617-95-95 42.617-95 95-95 95 42.617 95 95zM94.787 256H30v-15h64.787c.844 5.006 1.943 9.931 3.213 14.787v.213zm322.426 0c1.27-4.856 2.369-9.781 3.213-14.787V256H482v15h-64.787v-.213zM240 151c-36.22 0-68.653 17.317-89.231 44.041-2.951-1.206-5.973-2.267-9.055-3.188C158.588 153.419 196.584 121 240 121c43.416 0 81.412 32.419 98.286 70.853-3.082.921-6.104 1.982-9.055 3.188C308.653 168.317 276.22 151 240 151z" fill="currentColor" opacity="1" data-original="currentColor" />
                      <path d="M240 241c-8.284 0-15 6.716-15 15v60c0 8.284 6.716 15 15 15s15-6.716 15-15v-60c0-8.284-6.716-15-15-15zM197.574 257.574c-5.858-5.858-15.355-5.858-21.213 0l-42.426 42.426c-5.858 5.858-5.858 15.355 0 21.213 2.929 2.929 6.768 4.394 10.606 4.394s7.678-1.464 10.606-4.394l42.426-42.426c5.859-5.858 5.859-15.355.001-21.213zM324.852 279.787c2.929 2.929 6.768 4.394 10.606 4.394s7.678-1.464 10.606-4.394c5.858-5.858 5.858-15.355 0-21.213l-42.426-42.426c-5.857-5.858-15.355-5.858-21.213 0s-5.858 15.355 0 21.213l42.427 42.426z" fill="currentColor" opacity="1" data-original="currentColor" />
                    </g>
                  </svg>

                </div>
                <div class="service-item-content">
                  <h3 class="service-heading">Irrigation and Water Management</h3>
                  <p>
                    Drone-assisted assessment of moisture levels and irrigation efficiency for optimized water use and improved crop performance.
                  </p>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6">
              <div class="service-item h-100">
                <span class="number">05</span>
                <div class="service-item-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="80" height="80" x="0" y="0" viewBox="0 0 512 512" style="enable-background: new 0 0 512 512" xml:space="preserve" class="">
                    <g>
                      <path d="M507.606 108.395c-5.857-5.858-15.355-5.858-21.213 0L271 323.787V15c0-8.284-6.716-15-15-15s-15 6.716-15 15v308.787L25.607 108.395c-5.857-5.858-15.355-5.858-21.213 0s-5.858 15.355 0 21.213l215.393 215.393H15c-8.284 0-15 6.716-15 15v137c0 8.284 6.716 15 15 15h482c8.284 0 15-6.716 15-15v-137c0-8.284-6.716-15-15-15H292.213L507.606 129.608c5.858-5.858 5.858-15.355 0-21.213zM30 375.001h84v106H30v-106zm114 106v-106h84v106h-84zm114 0v-106h84v106h-84zm114 0v-106h84v106h-84zm114 0h-54v-106h54v106z" fill="currentColor" opacity="1" data-original="currentColor" />
                    </g>
                  </svg>

                </div>
                <div class="service-item-content">
                  <h3 class="service-heading">Crop Health and Yield Forecasting</h3>
                  <p>
                    AI-based analytics to monitor crop growth stages and predict yields for improved planning and profitability.
                  </p>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6">
              <div class="service-item h-100">
                <span class="number">06</span>
                <div class="service-item-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="80" height="80" x="0" y="0" viewBox="0 0 512 512" style="enable-background: new 0 0 512 512" xml:space="preserve" class="">
                    <g>
                      <path d="M437 0H75C65.611 0 58 7.611 58 17v478c0 9.389 7.611 17 17 17h362c9.389 0 17-7.611 17-17V17c0-9.389-7.611-17-17-17zm-17 478H92V34h328v444z" fill="currentColor" opacity="1" data-original="currentColor" />
                      <path d="M138 118h236c8.284 0 15-6.716 15-15s-6.716-15-15-15H138c-8.284 0-15 6.716-15 15s6.716 15 15 15zM374 148H138c-8.284 0-15 6.716-15 15s6.716 15 15 15h236c8.284 0 15-6.716 15-15s-6.716-15-15-15zM178 378h30V268c0-8.284-6.716-15-15-15s-15 6.716-15 15v110zM241 378h30V228c0-8.284-6.716-15-15-15s-15 6.716-15 15v150zM304 378h30V298c0-8.284-6.716-15-15-15s-15 6.716-15 15v80zM153 423h206c8.284 0 15-6.716 15-15s-6.716-15-15-15H153c-8.284 0-15 6.716-15 15s6.716 15 15 15z" fill="currentColor" opacity="1" data-original="currentColor" />
                    </g>
                  </svg>

                </div>
                <div class="service-item-content">
                  <h3 class="service-heading">Agricultural Data Reporting and Advisory</h3>
                  <p>
                    Actionable insights and reports generated from aerial data, supported by expert analysis from agronomists and data scientists.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section><!-- /Services Section -->

    <!-- About Section -->
    <section id="about" class="about section">

      <div class="content">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 mb-4 mb-lg-0">
              <img src="assets/img/img3.jpg" alt="Image " class="img-fluid img-overlap" data-aos="zoom-out">
              <video class="img-fluid mt-4" style="width: 50%; height: 50%;" controls data-aos="zoom-out">
                <source src="assets/img/vd3.mp4" type="video/mp4">
                Your browser does not support the video tag.
              </video>
            </div>
            <div class="col-lg-5 ml-auto" data-aos="fade-up" data-aos-delay="100">
              <h3 class="content-subtitle text-white opacity-50">Why Choose Us</h3>
              <h2 class="content-title mb-4">
                We Have <strong>Expertise In</strong> Drone Technology
              </h2>
              <div class="row my-5">
                <!-- AI-Powered Precision -->
                <div class="col-lg-12 d-flex align-items-start mb-4">
                  <i class="bi bi-cpu me-4 display-6"></i>
                  <div>
                    <h4 class="m-0 h5 text-white">AI-Powered Precision:</h4>
                    <p class="text-white opacity-50">
                      We combine artificial intelligence and drone technology to deliver accurate, real-time data that supports smart decision-making.
                    </p>
                  </div>
                </div>

                <!-- Tailored Solutions -->
                <div class="col-lg-12 d-flex align-items-start mb-4">
                  <i class="bi bi-sliders2 me-4 display-6"></i>
                  <div>
                    <h4 class="m-0 h5 text-white">Tailored Solutions:</h4>
                    <p class="text-white opacity-50">
                      Our services are designed to meet the specific needs of both smallholder and commercial farmers, ensuring relevance and impact.
                    </p>
                  </div>
                </div>

                <!-- Cost Efficiency -->
                <div class="col-lg-12 d-flex align-items-start mb-4">
                  <i class="bi bi-cash-coin me-4 display-6"></i>
                  <div>
                    <h4 class="m-0 h5 text-white">Cost Efficiency:</h4>
                    <p class="text-white opacity-50">
                      We help farmers cut operational costs by optimizing inputs and minimizing losses through precision management.
                    </p>
                  </div>
                </div>

                <!-- Expert Team -->
                <div class="col-lg-12 d-flex align-items-start mb-4">
                  <i class="bi bi-people-fill me-4 display-6"></i>
                  <div>
                    <h4 class="m-0 h5 text-white">Expert Team:</h4>
                    <p class="text-white opacity-50">
                      Our multidisciplinary team of engineers, agronomists, economists and data analysts ensures that every service is scientifically sound and practically valuable.
                    </p>
                  </div>
                </div>

                <!-- Commitment to Growth -->
                <div class="col-lg-12 d-flex align-items-start mb-4">
                  <i class="bi bi-graph-up-arrow me-4 display-6"></i>
                  <div>
                    <h4 class="m-0 h5 text-white">Commitment to Growth:</h4>
                    <p class="text-white opacity-50">
                      We are not just service providers—we are partners in your journey toward increased productivity, profitability, and sustainability.
                    </p>
                  </div>
                </div>

                <!-- Compliance to Safety Standards -->
                <div class="col-lg-12 d-flex align-items-start mb-4">
                  <i class="bi bi-shield-check me-4 display-6"></i>
                  <div>
                    <h4 class="m-0 h5 text-white">Compliance to Safety Standards:</h4>
                    <p class="text-white opacity-50">
                      You are safe in our hands. While operating with an approved Remotely Piloted Aircraft Certificate (ROC), we also maintain a comprehensive
                      Safety Management System in line with Civil Aviation Authority of Zimbabwe (CAAZ) regulations, on and off-field.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section><!-- /About Section -->

    <!-- About 3 Section -->
    <!-- <section id="about-3" class="about-3 section">

      <div class="container">
        <div class="row gy-4 justify-content-between align-items-center">
          <div class="col-lg-6 order-lg-2 position-relative" data-aos="zoom-out">
            <img src="assets/img/img_sq_1.jpg" alt="Image" class="img-fluid">
            <a href="https://www.youtube.com/watch?v=Y7f98aduVJ8" class="glightbox pulsating-play-btn">
              <span class="play"><i class="bi bi-play-fill"></i></span>
            </a>
          </div>
          <div class="col-lg-5 order-lg-1" data-aos="fade-up" data-aos-delay="100">
            <h2 class="content-title mb-4">Plants Make Life Better</h2>
            <p class="mb-4">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim
              necessitatibus placeat, atque qui voluptatem velit explicabo vitae
              repellendus architecto provident nisi ullam minus asperiores commodi!
              Tenetur, repellat aliquam nihil illo.
            </p>
            <ul class="list-unstyled list-check">
              <li>Lorem ipsum dolor sit amet</li>
              <li>Velit explicabo vitae repellendu</li>
              <li>Repellat aliquam nihil illo</li>
            </ul>

            <p><a href="#" class="btn-cta">Get in touch</a></p>
          </div>
        </div>
      </div>
    </section> -->

    <!-- /About 3 Section -->

    <!-- Services 2 Section -->
    <section id="services-2" class="services-2 section dark-background">
      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Services</h2>
        <p>Browse Through Our Services</p>
      </div><!-- End Section Title -->

      <div class="services-carousel-wrap">
        <div class="container">
          <div class="swiper init-swiper">
            <script type="application/json" class="swiper-config">
              {
                "loop": true,
                "speed": 600,
                "autoplay": {
                  "delay": 5000
                },
                "slidesPerView": "auto",
                "pagination": {
                  "el": ".swiper-pagination",
                  "type": "bullets",
                  "clickable": true
                },
                "navigation": {
                  "nextEl": ".js-custom-next",
                  "prevEl": ".js-custom-prev"
                },
                "breakpoints": {
                  "320": {
                    "slidesPerView": 1,
                    "spaceBetween": 40
                  },
                  "1200": {
                    "slidesPerView": 3,
                    "spaceBetween": 40
                  }
                }
              }
            </script>
            <button class="navigation-prev js-custom-prev">
              <i class="bi bi-arrow-left-short"></i>
            </button>
            <button class="navigation-next js-custom-next">
              <i class="bi bi-arrow-right-short"></i>
            </button>

            <style>
              .service-item {
                position: relative;
                overflow: hidden;
                border-radius: 12px;
              }

              .service-img {
                width: 100%;
                height: 350px;
                /* Adjust this height as needed */
                object-fit: cover;
                /* Keeps consistent size and crops edges */
                border-radius: 12px;
                transition: transform 0.4s ease;
              }

              /* Optional hover effect for style */
              .service-img:hover {
                transform: scale(1.05);
              }
            </style>

            <div class="swiper-wrapper">
              <div class="swiper-slide">
                <div class="service-item">
                  <div class="service-item-contents">
                    <a href="#">
                      <span class="service-item-category">We do</span>
                      <h2 class="service-item-title">Precision Crop Monitoring and Analysis</h2>
                    </a>
                  </div>
                  <img src="assets/img/img3.jpg" alt="Image" class="img-fluid service-img">
                </div>
              </div>

              <div class="swiper-slide">
                <div class="service-item">
                  <div class="service-item-contents">
                    <a href="#">
                      <span class="service-item-category">We do</span>
                      <h2 class="service-item-title">Aerial Crop Protection and Spraying</h2>
                    </a>
                  </div>
                  <img src="assets/img/img7.jpg" alt="Image" class="img-fluid service-img">
                </div>
              </div>

              <div class="swiper-slide">
                <div class="service-item">
                  <div class="service-item-contents">
                    <a href="#">
                      <span class="service-item-category">We do</span>
                      <h2 class="service-item-title">Soil Mapping and Analysis</h2>
                    </a>
                  </div>
                  <img src="assets/img/img5.jpg" alt="Image" class="img-fluid service-img">
                </div>
              </div>

              <div class="swiper-slide">
                <div class="service-item">
                  <div class="service-item-contents">
                    <a href="#">
                      <span class="service-item-category">We do</span>
                      <h2 class="service-item-title">Irrigation and Water Management</h2>
                    </a>
                  </div>
                  <img src="assets/img/img8.jpg" alt="Image" class="img-fluid service-img">
                </div>
              </div>

              <div class="swiper-slide">
                <div class="service-item">
                  <div class="service-item-contents">
                    <a href="#">
                      <span class="service-item-category">We do</span>
                      <h2 class="service-item-title">Crop Health and Yield Forecasting</h2>
                    </a>
                  </div>
                  <img src="assets/img/img6.jpg" alt="Image" class="img-fluid service-img">
                </div>
              </div>
            </div>


          </div>
          <div class="swiper-pagination"></div>
        </div>
      </div>
      </div>
    </section><!-- /Services 2 Section -->

    <!-- Testimonials Section -->
    <!-- <section class="testimonials-12 testimonials section" id="testimonials">
      Section Title -->
    <!-- <div class="container section-title" data-aos="fade-up">
        <h2>TESTIMONIALS</h2>
        <p>Necessitatibus eius consequatur</p>
      </div>
      <div class="testimonial-wrap">
        <div class="container">
          <div class="row">
            <div class="col-md-6 mb-4 mb-md-4">
              <div class="testimonial">
                <img src="assets/img/testimonials/testimonials-1.jpg" alt="Testimonial author">
                <blockquote>
                  <p>
                    “Lorem ipsum dolor sit, amet consectetur adipisicing
                    elit. Provident deleniti iusto molestias, dolore vel fugiat
                    ab placeat ea?”
                  </p>
                </blockquote>
                <p class="client-name">James Smith</p>
              </div>
            </div>
            <div class="col-md-6 mb-4 mb-md-4">
              <div class="testimonial">
                <img src="assets/img/testimonials/testimonials-2.jpg" alt="Testimonial author">
                <blockquote>
                  <p>
                    “Lorem ipsum dolor sit, amet consectetur adipisicing
                    elit. Provident deleniti iusto molestias, dolore vel fugiat
                    ab placeat ea?”
                  </p>
                </blockquote>
                <p class="client-name">Kate Smith</p>
              </div>
            </div>
            <div class="col-md-6 mb-4 mb-md-4">
              <div class="testimonial">
                <img src="assets/img/testimonials/testimonials-3.jpg" alt="Testimonial author">
                <blockquote>
                  <p>
                    “Lorem ipsum dolor sit, amet consectetur adipisicing
                    elit. Provident deleniti iusto molestias, dolore vel fugiat
                    ab placeat ea?”
                  </p>
                </blockquote>
                <p class="client-name">Claire Anderson</p>
              </div>
            </div>
            <div class="col-md-6 mb-4 mb-md-4">
              <div class="testimonial">
                <img src="assets/img/testimonials/testimonials-4.jpg" alt="Testimonial author">
                <blockquote>
                  <p>
                    “Lorem ipsum dolor sit, amet consectetur adipisicing
                    elit. Provident deleniti iusto molestias, dolore vel fugiat
                    ab placeat ea?”
                  </p>
                </blockquote>
                <p class="client-name">Dan Smith</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
 --> <!-- /Testimonials Section -->

    <!-- Recent Posts Section -->
    <!-- <section id="recent-posts" class="recent-posts section">

   
      <div class="container section-title" data-aos="fade-up">
        <h2>Recent Posts</h2>
        <p>Necessitatibus eius consequatur</p>
      </div>

      <div class="container">

        <div class="row gy-5">

          <div class="col-xl-4 col-md-6">
            <div class="post-item position-relative h-100" data-aos="fade-up" data-aos-delay="100">

              <div class="post-img position-relative overflow-hidden">
                <img src="assets/img/blog/blog-1.jpg" class="img-fluid" alt="">
                <span class="post-date">December 12</span>
              </div>

              <div class="post-content d-flex flex-column">

                <h3 class="post-title">Eum ad dolor et. Autem aut fugiat debitis</h3>

                <div class="meta d-flex align-items-center">
                  <div class="d-flex align-items-center">
                    <i class="bi bi-person"></i> <span class="ps-2">Julia Parker</span>
                  </div>
                  <span class="px-3 text-black-50">/</span>
                  <div class="d-flex align-items-center">
                    <i class="bi bi-folder2"></i> <span class="ps-2">Politics</span>
                  </div>
                </div>

                <hr>

                <a href="blog-details.html" class="readmore stretched-link"><span>Read More</span><i class="bi bi-arrow-right"></i></a>

              </div>

            </div>
          </div>

          <div class="col-xl-4 col-md-6">
            <div class="post-item position-relative h-100" data-aos="fade-up" data-aos-delay="200">

              <div class="post-img position-relative overflow-hidden">
                <img src="assets/img/blog/blog-2.jpg" class="img-fluid" alt="">
                <span class="post-date">July 17</span>
              </div>

              <div class="post-content d-flex flex-column">

                <h3 class="post-title">Et repellendus molestiae qui est sed omnis</h3>

                <div class="meta d-flex align-items-center">
                  <div class="d-flex align-items-center">
                    <i class="bi bi-person"></i> <span class="ps-2">Mario Douglas</span>
                  </div>
                  <span class="px-3 text-black-50">/</span>
                  <div class="d-flex align-items-center">
                    <i class="bi bi-folder2"></i> <span class="ps-2">Sports</span>
                  </div>
                </div>

                <hr>

                <a href="blog-details.html" class="readmore stretched-link"><span>Read More</span><i class="bi bi-arrow-right"></i></a>

              </div>

            </div>
          </div>

          <div class="col-xl-4 col-md-6" data-aos="fade-up" data-aos-delay="300">
            <div class="post-item position-relative h-100">

              <div class="post-img position-relative overflow-hidden">
                <img src="assets/img/blog/blog-3.jpg" class="img-fluid" alt="">
                <span class="post-date">September 05</span>
              </div>

              <div class="post-content d-flex flex-column">

                <h3 class="post-title">Quia assumenda est et veritati tirana ploder</h3>

                <div class="meta d-flex align-items-center">
                  <div class="d-flex align-items-center">
                    <i class="bi bi-person"></i> <span class="ps-2">Lisa Hunter</span>
                  </div>
                  <span class="px-3 text-black-50">/</span>
                  <div class="d-flex align-items-center">
                    <i class="bi bi-folder2"></i> <span class="ps-2">Economics</span>
                  </div>
                </div>

                <hr>

                <a href="blog-details.html" class="readmore stretched-link"><span>Read More</span><i class="bi bi-arrow-right"></i></a>

              </div>

            </div>
          </div>

        </div>

      </div>

    </section> --><!-- /Recent Posts Section -->

<?php
  include('includes/subscriber.php');
  include('includes/whatsapp.php');
  ?>

  </main>

  <?php
  include('includes/footer.php');
  ?>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>




</body>

</html>