<?php
include('includes/head.php');
?>

<body class="about-page">

  <?php
  include('includes/header.php');
  ?>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title dark-background" data-aos="fade" style="background-image: url(assets/img/page-title-bg.webp);">
      <div class="container position-relative">
        <h1>About Us</h1>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">About</li>
          </ol>
        </nav>
      </div>
    </div><!-- End Page Title -->

    <!-- About 3 Section -->
    <section id="about-3" class="about-3 section">

      <div class="container">
        <div class="row gy-4 justify-content-between align-items-start">
          <!-- Image Column - Stays on right -->
          <div class="col-lg-6 order-lg-2 position-relative" data-aos="zoom-out">
            <img src="assets/img/img1.jpg" alt="Image" class="img-fluid sticky-top" style="top: 20px;">
            <!-- will replace the video later -->
            <a href="https://www.youtube.com/watch?v=Y7f98aduVJ8" class="glightbox pulsating-play-btn">
              <!-- <a href="C:/xampp/htdocs/nexal/assets/img" class="glightbox pulsating-play-btn"> -->
            <span class="play"><i class="bi bi-play-fill"></i></span>
            </a>
          </div>

          <!-- Content Column - Left side -->
          <div class="col-lg-5 order-lg-1" data-aos="fade-up" data-aos-delay="100">
            <!-- Background -->
            <div class="mb-5">
              <h2 class="content-title mb-4">Background</h2>
              <p class="mb-4" style="text-align: justify;">
                Nexal Innovations (Pvt) Ltd is a Zimbabwe-based Agri-technology company with a vision to
                revolutionize the farming landscape by integrating cutting-edge drone technology into everyday
                agricultural practices. Guided by our motto,
                <a href="#" id="readMoreLink" style="color: #007bff; text-decoration: underline;">Read more</a>
              </p>
            </div>

            <!-- Mission -->
            <div class="mb-5">
              <h2 class="content-title mb-4">Mission</h2>
              <p style="text-align: justify;">
                To provide AI-powered, cost effective and data driven drone solutions that simplify farming operations,
                reduce costs, improve decision making and promote the development of productive and sustainable farming systems.
              </p>
            </div>

            <!-- Vision -->
            <div class="mb-5">
              <h2 class="content-title mb-4">Vision</h2>
              <p style="text-align: justify;">
                To modernise African agriculture through innovative drone technology that empowers farmers to efficiently make
                smarter, data-driven decisions for a profitable and sustainable farming systems.</p>
            </div>

            <!-- Core Values -->
            <div class="mb-5">
              <h2 class="content-title mb-4">Core Values</h2>
              <ul class="list-unstyled" style="text-align: justify;">
                <li class="mb-3">
                  <strong><i class="bi bi-check-circle-fill text-primary me-2"></i>Safety:</strong>
                  We ensure all our operations are guided by a strict aviation and environmental safety standards.
                </li>
                <li class="mb-3">
                  <strong><i class="bi bi-check-circle-fill text-primary me-2"></i>Innovation:</strong>
                  We continuously push the boundaries of agricultural technology to deliver smart, efficient, and practical solutions for farmers.
                </li>
                <li class="mb-3">
                  <strong><i class="bi bi-check-circle-fill text-primary me-2"></i>Sustainability:</strong>
                  We promote environmentally responsible farming practices that protect natural resources and ensure long-term productivity.
                </li>
                <li class="mb-3">
                  <strong><i class="bi bi-check-circle-fill text-primary me-2"></i>Excellence:</strong>
                  We are committed to delivering high-quality, data-driven services that add real value to our clients’ operations.
                </li>
                <li class="mb-3">
                  <strong><i class="bi bi-check-circle-fill text-primary me-2"></i>Collaboration:</strong>
                  We believe in partnerships—with farmers, agribusinesses, and communities—to co-create impactful solutions.
                </li>
                <li class="mb-3">
                  <strong><i class="bi bi-check-circle-fill text-primary me-2"></i>Integrity:</strong>
                  We operate with transparency, professionalism, and accountability in all our engagements.
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal Dialog -->
      <div class="modal fade" id="backgroundModal" tabindex="-1" aria-labelledby="backgroundModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="backgroundModalLabel">Background</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" style="text-align: justify;">
              <p>
                Nexal Innovations (Pvt) Ltd is a Zimbabwe-based Agri-technology company with a vision to revolutionize the farming landscape by
                integrating cutting-edge drone technology into everyday agricultural practices. Guided by our motto, ‘Farm smart, not hard with our drones
                that give you power to cut costs,” we are committed to helping farmers and agribusinesses embrace precision agriculture and data driven
                decision making for sustainable farming.
              </p>
              <p>
                We specialize in offering AI powered drone services specifically designed to sustainably optimize agricultural productivity.
                From precision aerial crop monitoring and protection, soil mapping and analysis to irrigation management and fertiliser application,
                our drones provide farmers with accurate insights that improve decision making, enhance efficiency, reduce input costs, minimize crop losses
                and maximize yields.
              </p>
              <p>
                At Nexal Innovations, we combine regulatory compliance and technological expertise with a deep understanding of the agriculture sector.
                Our certified and multidisciplinary team of licensed pilots, agronomists, engineers and data analysts deliver reliable, scalable and cost
                effective drone services tailored to the needs of smallholder and commercial farmers alike.
              </p>
              <p>
                Headquartered in Harare, Zimbabwe, Nexal Innovations is on a mission to drive the digital transformation of agriculture across the
                region. By combining cutting-edge drone technology with practical farming insights, we are building a smarter, more resilient, and sustainable
                agricultural future for Africa. We believe that the future of farming lies in smart technology — and we are here to make that
                future accessible to every farmer.
              </p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>
    </section><!-- /About 3 Section -->

    <!-- Team Section -->
    <section class="team-15 team section" id="team">
      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Our Team</h2>
      </div><!-- End Section Title -->

      <div class="content">
        <div class="container">
          <div class="row">
            <div class="col-lg-3 col-md-6 mb-4">
              <div class="person">
                <figure>
                  <img src="assets/img/team/Mavis Moyo.jpg" alt="Image" class="img-fluid">
                  <div class="social">
                    <a href="#"><span class="bi bi-facebook"></span></a>
                    <a href="#"><span class="bi bi-twitter-x"></span></a>
                    <a href="#"><span class="bi bi-linkedin"></span></a>
                  </div>
                </figure>
                <div class="person-contents">
                  <h3>Mavis Moyo</h3>
                  <span class="position">Accountable Manager</span>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-4">
              <div class="person">
                <figure>
                  <img src="assets/img/team/Tafadzwa Chademana.jpg" alt="Image" class="img-fluid">
                  <div class="social">
                    <a href="#"><span class="bi bi-facebook"></span></a>
                    <a href="#"><span class="bi bi-twitter-x"></span></a>
                    <a href="#"><span class="bi bi-linkedin"></span></a>
                  </div>
                </figure>
                <div class="person-contents">
                  <h3>Tafadzwa Chademana</h3>
                  <span class="position">Quality Manager</span>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-4">
              <div class="person">
                <figure>
                  <img src="assets/img/team/Blessing Kokera.jpg" alt="Image" class="img-fluid">
                  <div class="social">
                    <a href="#"><span class="bi bi-facebook"></span></a>
                    <a href="#"><span class="bi bi-twitter-x"></span></a>
                    <a href="#"><span class="bi bi-linkedin"></span></a>
                  </div>
                </figure>
                <div class="person-contents">
                  <h3>Blessing Kokera</h3>
                  <span class="position">Chief Pilot</span>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-4">
              <div class="person">
                <figure>
                  <img src="assets/img/team/Chengeto Koza.jpg" alt="Image" class="img-fluid">
                  <div class="social">
                    <a href="#"><span class="bi bi-facebook"></span></a>
                    <a href="#"><span class="bi bi-twitter-x"></span></a>
                    <a href="#"><span class="bi bi-linkedin"></span></a>
                  </div>
                </figure>
                <div class="person-contents">
                  <h3>Chengetai Koza</h3>
                  <span class="position">Safety Manager</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </section><!-- /Team Section -->

    



  <?php
  include('includes/subscriber.php');
  ?>

  </main>


  <?php
  include('includes/footer.php');
  ?>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>
  <!-- JavaScript to trigger the modal -->
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const readMoreLink = document.getElementById('readMoreLink');
      const backgroundModal = new bootstrap.Modal(document.getElementById('backgroundModal'));

      readMoreLink.addEventListener('click', function(e) {
        e.preventDefault();
        backgroundModal.show();
      });
    });
  </script>

</body>

</html>