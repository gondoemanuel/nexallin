<div class="whatsapp-widget">
  <a href="https://wa.me/263776824115?text=Hello%20Nexal,%20I'm%20interested%20in%20your%20drone%20services.%20Can%20you%20help%20me?" target="_blank" class="whatsapp-button">
    <i class="bi bi-whatsapp"></i>
  </a>
</div>
