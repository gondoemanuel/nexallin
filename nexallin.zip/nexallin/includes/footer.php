<footer id="footer" class="footer dark-background">

  <div class="footer-top">
    <div class="container">
      <div class="row gy-4">
        <div class="col-lg-4 col-md-6 footer-about">
          <a href="index" class="logo d-flex align-items-center">
            <span class="sitename">AgriTech</span>
          </a>
          <div class="footer-contact pt-3">
            <p>83 Broadlands Road,</p>
            <p>Emerald Hill, Harare</p>
            <p class="mt-3"><strong>Phone:</strong> <span>+263 776 824 115 / +263 774 654 602</span></p>
            <p><strong>Email:</strong>
              <span>
                <a href="mailto:mavis.moyo@nexal.co.zw">mavis.moyo@nexal.co.zw</a> /
                <a href="mailto:chenge.koza@nexal.co.zw">chenge.koza@nexal.co.zw</a>
              </span>
            </p>
          </div>
        </div>

        <div class="col-lg-4 col-md-3 footer-links">
          <h4>Useful Links</h4>
          <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">About us</a></li>
            <li><a href="#">Services</a></li>
            <li><a href="#">Terms of service</a></li>
            <li><a href="#">Privacy policy</a></li>
          </ul>
        </div>

        <div class="col-lg-4 col-md-3 footer-links">
          <h4>Our Services</h4>
          <ul>
            <li><a href="#">Precision Crop Monitoring and Analysis</a></li>
            <li><a href="#">Aerial Crop Protection and Spraying</a></li>
            <li><a href="#">Soil Mapping and Analysis</a></li>
            <li><a href="#">Irrigation and Water Management</a></li>
            <li><a href="#">Crop Health and Yield Forecasting</a></li>
            <li><a href="#">Agricultural Data Reporting and Advisory</a></li>
          </ul>
        </div>

      </div>
    </div>
  </div>


  <div class="copyright text-center">
    <div class="container d-flex flex-column flex-lg-row justify-content-center justify-content-lg-between align-items-center">

      <div class="d-flex flex-column align-items-center align-items-lg-start">
        <div>
          © Copyright <strong><span>www.nexal.co.zw</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
          <!-- All the links in the footer should remain intact. -->
          <!-- You can delete the links only if you purchased the pro version. -->
          <!-- Licensing information: https://bootstrapmade.com/license/ -->
          <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/herobiz-bootstrap-business-template/ -->
          Designed by <a href="#"></a> Eagle-Techie</a>
        </div>
      </div>

      <div class="social-links order-first order-lg-last mb-3 mb-lg-0">
        <a href=""><i class="bi bi-twitter-x"></i></a>
        <a href=""><i class="bi bi-facebook"></i></a>
        <a href=""><i class="bi bi-instagram"></i></a>
        <a href=""><i class="bi bi-linkedin"></i></a>
      </div>

    </div>
  </div>

</footer>