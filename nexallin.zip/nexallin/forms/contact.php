<?php
// Configuration
$receiving_email = 'chenge.koza@nexal.co.zw';
$from_email = 'noreply@nexal.co.zw';

// Check request method
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    die("Method not allowed");
}

// Get form data
$name = isset($_POST["name"]) ? trim($_POST["name"]) : '';
$email = isset($_POST["email"]) ? trim($_POST["email"]) : '';
$subject = isset($_POST["subject"]) ? trim($_POST["subject"]) : '';
$message = isset($_POST["message"]) ? trim($_POST["message"]) : '';

// Validate
if (empty($name) || empty($email) || empty($subject) || empty($message)) {
    http_response_code(400);
    die("All fields are required");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    die("Invalid email address");
}

// Sanitize
$name = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
$email = htmlspecialchars($email, ENT_QUOTES, 'UTF-8');
$subject = htmlspecialchars($subject, ENT_QUOTES, 'UTF-8');
$message = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');

// Prepare email
$to =$receiving_email;
$email_subject = "Contact Form: " . $subject;
$email_body = "You have received a new message from the Nexal contact form.\n\n";
$email_body .= "Name: $name\n";
$email_body .= "Email: $email\n";
$email_body .= "Subject: $subject\n\n";
$email_body .= "Message:\n$message\n";

// Email headers
$headers = "From: " . $from_email . "\r\n";
$headers .= "Reply-To: " . $email . "\r\n";
$headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

// Send email
$mail_sent = @mail($to,$email_subject, $email_body,$headers);

if ($mail_sent) {
    http_response_code(200);
    echo "OK";
} else {
    http_response_code(500);
    die("Failed to send email. Please try again later.");
}
?>
