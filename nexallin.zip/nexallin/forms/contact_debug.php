<?php
header('Content-Type: text/plain');

echo "=== DEBUG INFO ===\n\n";
echo "Request Method: " . $_SERVER["REQUEST_METHOD"] . "\n";
echo "Content Type: " . (isset($_SERVER["CONTENT_TYPE"]) ? $_SERVER["CONTENT_TYPE"] : "Not set") . "\n\n";

echo "POST Data:\n";
print_r($_POST);

echo "\n\nRaw Input:\n";
echo file_get_contents('php://input');
?>
