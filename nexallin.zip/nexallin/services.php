<?php
include('includes/head.php');
?>

<body class="services-page">
  <?php include('includes/header.php'); ?>

  <main class="main">
    <!-- Page Title -->
    <div class="page-title dark-background" data-aos="fade" style="background-image: url('assets/img/Drone spraying.jpg');">
      <div class="container position-relative">
        <h1>Our Services</h1>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">Our Services</li>
          </ol>
        </nav>
      </div>
    </div><!-- End Page Title -->

    <!-- WHO WE ARE Section (from uploaded poster) -->
    <section id="who-we-are" class="section">
      <div class="container">
        <div class="section-title" data-aos="fade-up">
          <h2 class="text-green">WHO WE ARE</h2>
          <p class="mb-0">
            Nexal Innovations is a Zimbabwean agritech company offering AI-driven drone solutions for spraying, mapping, and field analytics — transforming farming efficiency, sustainability, and decision-making.
          </p>
        </div>
      </div>
    </section>

    <!-- Services Section (aligned with uploaded poster) -->
    <section id="services" class="services section">
      <div class="container section-title" data-aos="fade-up">
        <h2 class="text-maize">OUR SERVICES</h2>
        <p>AI-driven spraying, mapping, field intelligence, and crop health monitoring</p>
      </div>

      <div class="content">
        <div class="container">
          <div class="row g-4">

            <!-- Precision Application Services -->
            <div class="col-lg-4 col-md-6">
              <div class="service-item" data-aos="fade-up" data-aos-delay="100">
                <div class="service-icon" aria-hidden="true">
                  <!-- Drone sprayer icon -->
                  <svg xmlns="http://www.w3.org/2000/svg" width="54" height="54" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M3 6h4l3 3h4l3-3h4" />
                    <rect x="9" y="9" width="6" height="4" rx="1" />
                    <path d="M6 13v3m12-3v3" />
                    <path d="M5 18h2M17 18h2" />
                    <path d="M9 15l-1 2M15 15l1 2" />
                  </svg>
                </div>
                <div class="service-item-content">
                  <h3 class="service-heading">Precision Application Services</h3>
                  <ul class="service-bullets">
                    <li>Optimized and uniform application of fertilizers, pesticides, and foliar feeds</li>
                    <li>UAV coverage and mapping for safer operations</li>
                    <li>Real-time field monitoring for accurate disease scouting, ripening, stand establishment, and field-area verification</li>
                    <li>Geo-tagged photographic reports and compliance mapping</li>
                  </ul>
                </div>
              </div>
            </div>

            <!-- Field Intelligence & Mapping Solutions -->
            <div class="col-lg-4 col-md-6">
              <div class="service-item" data-aos="fade-up" data-aos-delay="200">
                <div class="service-icon" aria-hidden="true">
                  <!-- Map/layers icon -->
                  <svg xmlns="http://www.w3.org/2000/svg" width="54" height="54" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M12 2l9 5-9 5-9-5 9-5z" />
                    <path d="M3 12l9 5 9-5" />
                    <path d="M3 17l9 5 9-5" />
                  </svg>
                </div>
                <div class="service-item-content">
                  <h3 class="service-heading">Field Intelligence & Mapping Solutions</h3>
                  <ul class="service-bullets">
                    <li>High-resolution field mapping for area measurement</li>
                    <li>Plant-population analysis and canopy coverage</li>
                    <li>Soil sampling, mapping, and fertility recommendations</li>
                    <li>Drone-based detection of soil pH and nutrient variability</li>
                    <li>Fertility and variability maps guiding precision input use</li>
                  </ul>
                </div>
              </div>
            </div>

            <!-- Crop Health & Monitoring System -->
            <div class="col-lg-4 col-md-6">
              <div class="service-item" data-aos="fade-up" data-aos-delay="300">
                <div class="service-icon" aria-hidden="true">
                  <!-- NDVI/health icon -->
                  <svg xmlns="http://www.w3.org/2000/svg" width="54" height="54" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M3 12h4l2-3 3 6 2-3h7" />
                    <circle cx="5" cy="12" r="2" />
                    <circle cx="19" cy="12" r="2" />
                    <path d="M12 19c3 0 6-2 6-5" />
                  </svg>
                </div>
                <div class="service-item-content">
                  <h3 class="service-heading">Crop Health & Monitoring System</h3>
                  <ul class="service-bullets">
                    <li>Early detection of disease outbreaks and water stress using NDVI and vegetation indices</li>
                    <li>Enabling quick, targeted interventions and cost savings</li>
                  </ul>
                </div>
              </div>
            </div>

          </div><!-- /row -->
        </div><!-- /container -->
      </div><!-- /content -->
    </section>
    <!-- /Services Section -->

    <!-- CTA Section -->
    <section id="cta" class="cta section">
      <div class="container">
        <div class="row" data-aos="zoom-out">
          <div class="col-lg-9 text-center text-lg-start">
            <h3>Ready to farm smarter with AI-powered drones?</h3>
            <p>Book a consultation to unlock precision spraying, mapping, and actionable field intelligence.</p>
          </div>
          <div class="col-lg-3 cta-btn-container text-center">
            <a class="cta-btn align-middle" href="contact.php">Contact Us</a>
          </div>
        </div>
      </div>
    </section>

    <?php include('includes/subscriber.php'); ?>

  </main>

  <?php include('includes/footer.php'); ?>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center">
    <i class="bi bi-arrow-up-short"></i>
  </a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>